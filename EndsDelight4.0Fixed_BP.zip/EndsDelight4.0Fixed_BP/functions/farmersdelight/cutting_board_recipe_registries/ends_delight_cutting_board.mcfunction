scriptevent farmersdelight:cutting_board_recipe { "ingredients": { "item": "ends_delight:shulker_meat" }, "result": [{ "item": "ends_delight:shulker_meat_slice", "count": 2 }], "tool": { "tag": "farmersdelight:is_knife" }, "is_block_type": false, "sound": "use.wood" }

scriptevent farmersdelight:cutting_board_recipe { "ingredients": { "item": "ends_delight:roasted_shulker_meat" }, "result": [{ "item": "ends_delight:roasted_shulker_meat_slice", "count": 2 }], "tool": { "tag": "farmersdelight:is_knife" }, "is_block_type": false, "sound": "use.wood" }

scriptevent farmersdelight:cutting_board_recipe { "ingredients": { "item": "ends_delight:roasted_dragon_meat" }, "result": [{ "item": "ends_delight:roasted_dragon_meat_cuts", "count": 2 }], "tool": { "tag": "farmersdelight:is_knife" }, "is_block_type": false, "sound": "use.wood" }

scriptevent farmersdelight:cutting_board_recipe { "ingredients": { "item": "ends_delight:raw_dragon_meat" }, "result": [{ "item": "ends_delight:raw_dragon_meat_cuts", "count": 2 }], "tool": { "tag": "farmersdelight:is_knife" }, "is_block_type": false, "sound": "use.wood" }

scriptevent farmersdelight:cutting_board_recipe { "ingredients": { "item": "minecraft:ender_pearl" }, "result": [{ "item": "ends_delight:ender_pearl_grain", "count": 1 }], "tool": { "tag": "farmersdelight:is_knife" }, "is_block_type": false, "sound": "use.wood" }

scriptevent farmersdelight:cutting_board_recipe { "ingredients": { "item": "minecraft:chorus_fruit" }, "result": [{ "item": "ends_delight:chorus_fruit_grain", "count": 1 }], "tool": { "tag": "farmersdelight:is_knife" }, "is_block_type": false, "sound": "use.wood" }

scriptevent farmersdelight:cutting_board_recipe { "ingredients": { "item": "ends_delight:raw_ender_mite_meat" }, "result": [{ "item": "ends_delight:enderman_gristle", "count": 2 }], "tool": { "tag": "farmersdelight:is_knife" }, "is_block_type": false, "sound": "use.wood" }

scoreboard objectives remove farmersdelight_ends_delight_cutting_board